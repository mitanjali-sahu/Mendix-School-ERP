//>>built
define("dijit/form/nls/ko/validate",({invalidMessage:"입력된 값이 올바르지 않습니다.",missingMessage:"이 값은 필수입니다.",rangeMessage:"이 값은 범위를 벗어납니다."}));
